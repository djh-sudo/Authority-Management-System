#pragma once
#ifndef NAME_H
#define NAME_H
#include<string>
using namespace std;
string md(string strPlain);

#endif // 